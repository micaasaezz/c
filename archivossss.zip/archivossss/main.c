#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arraylist.h"
#include "func.h"


int main()
{
    ArrayList* casasDisponibles = al_newArrayList();
    ArrayList* casasVendidas = al_newArrayList();

    int opcion, i;
    char seguir = 's';
    eCasa* casaAux;

    //hardcodeaCasasD(casasDisponibles);

    leerArchivoVendidas(casasVendidas);
    leerArchivoDisp(casasDisponibles);

    do
    {
        opcion = menu();
        switch(opcion)
        {
            case 1://casa disponible
                agregarCasa(casasDisponibles);
                break;
            case 2://casa vendida
                if(!(casasDisponibles->isEmpty(casasDisponibles)))
                {
                    printf("ID - DIRECC - AMB - PRECIO\n");
                    for(i=0; i<casasDisponibles->len(casasDisponibles); i++)
                    {
                        casaAux = casasDisponibles->get(casasDisponibles, i);
                        printCasa(casaAux);
                    }
                    printf("\nEscriba el id de la casa que se va a agregar a vendidas: ");
                    scanf("%d", &i);
                    casaAux = buscaCasaPorId(casasDisponibles, i);
                    if(casaAux!=NULL)
                    {
                        agregarVendida(casaAux, casasDisponibles, casasVendidas);
                    }
                    else
                    {
                        printf("Id invalido!\n");
                    }
                }

                break;
            case 3://modificar
                break;
            case 4://listas
                listas(casasDisponibles, casasVendidas);
                break;
            case 5:
                seguir = 'n';
                cargarArchivos(casasDisponibles, casasVendidas);
                break;
            default:
                printf("Opcion invalida!\n");
                break;
        }
        system("pause");
        system("cls");


    }while(seguir == 's');

    return 0;
}
