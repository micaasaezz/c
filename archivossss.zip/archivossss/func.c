#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arraylist.h"
#include "func.h"

#define ID 1000

int menu()
{
    int opcion=0;

    printf("1- Agregar casa disponible.\n");
    printf("2- Agregar casa vendida.\n");
    printf("3- Modificar casa.\n");
    printf("4- Listas.\n");
    printf("5- Salir.\n");
    scanf("%d",&opcion);

    return opcion;
}

eCasa* newCasa()
{
    eCasa* casa;
    casa = (eCasa*) malloc(sizeof(eCasa));
    return casa;
}
eCasa* newCasaParam(char dir[], int ambientes, float precio, int id)
{
    eCasa* casa;
    casa = newCasa();
    casa->ambientes = ambientes;
    casa->precio = precio;
    strcpy(casa->direccion, dir);
    casa->id = id;

    return casa;
}

void agregarCasa(ArrayList* lista)
{
    eCasa* casa;
    char direccion[100];
    int ambientes, id;
    float precio;

    if(lista!=NULL)
    {
        printf("Ingrese la direccion de la casa: ");
        fflush(stdin);
        gets(direccion);

        printf("Ingrese la cantidad de ambientes de la casa: ");
        scanf("%d", &ambientes);

        printf("Ingrese el precio de la casa: ");
        scanf("%f", &precio);

        id = ID + lista->len(lista);

        casa = newCasaParam(direccion, ambientes, precio, id);

        if(casa!=NULL)
        {
            lista->add(lista, casa);
        }
    }
}

void printCasa(eCasa* casa)
{
    printf("%d - %s - %d - %.2f\n", casa->id, casa->direccion, casa->ambientes, casa->precio);
}

eCasa* buscaCasaPorId(ArrayList* lista, int id)
{
    eCasa* casa = NULL;
    eCasa* aux;
    int i;
    for(i=0; i< lista->len(lista); i++)
    {
        aux = lista->get(lista, i);
        if(aux->id == id)
        {
            casa = aux;
            break;
        }
    }

    return casa;
}

void agregarVendida(eCasa* casa, ArrayList* disponibles, ArrayList* vendidas)
{
    int i;
    eCasa* aux;

    if(casa!=NULL && disponibles!=NULL && vendidas!=NULL)
    {
        i = disponibles->indexOf(disponibles, casa);

        if(i!=-1)
        {
            aux = disponibles->pop(disponibles, i);

            if(aux == casa)
            {
                vendidas->add(vendidas, casa);
                printf("Se agrego correctamente!\n");
            }
            else
            {
                printf("Error.\n");
            }
        }
    }
}


void listas(ArrayList* disponibles, ArrayList* vendidas)
{
    int opcion, i;
    eCasa* casa;

    if(disponibles!=NULL && vendidas!=NULL)
    {
        printf("1- Disponibles\n2- Vendidas\n3- Ambas\n");
        scanf("%d", &opcion);
        switch(opcion)
        {
            case 1:
                if(disponibles->isEmpty(disponibles))
                {
                     printf("No hay casas disponibles para mostrar\n\n");
                }
                else
                {
                    printf("ID - DIRECC - AMB - PRECIO\n");
                    for(i=0; i< disponibles->len(disponibles); i++)
                    {
                        casa = disponibles->get(disponibles, i);
                        printCasa(casa);
                    }
                }
                break;
            case 2:
                if(vendidas->isEmpty(vendidas))
                {
                     printf("No hay casas vendidas para mostrar\n\n");
                }
                else
                {
                    printf("ID - DIRECC - AMB - PRECIO\n");
                    for(i=0; i< vendidas->len(vendidas); i++)
                    {
                        casa = vendidas->get(vendidas, i);
                        printCasa(casa);
                    }
                }
                break;
            case 3:
                if(disponibles->isEmpty(disponibles))
                {
                     printf("No hay casas disponibles para mostrar\n\n");
                }
                else
                {
                    printf("DISPONIBLES:\nID - DIRECC - AMB - PRECIO\n");
                    for(i=0; i< disponibles->len(disponibles); i++)
                    {
                        casa = disponibles->get(disponibles, i);
                        printCasa(casa);
                    }
                }
                if(vendidas->isEmpty(vendidas))
                {
                     printf("No hay casas vendidas para mostrar\n\n");
                }
                else
                {
                    printf("\n\nVENDIDAS:\nID - DIRECC - AMB - PRECIO\n");
                    for(i=0; i< vendidas->len(vendidas); i++)
                    {
                        casa = vendidas->get(vendidas, i);
                        printCasa(casa);
                    }
                }
                break;
            default:
                printf("Error.\n");
                break;
        }
    }
}


void cargarArchivos(ArrayList* disponibles, ArrayList* vendidas)
{
    FILE* archD;
    FILE* archV;
    eCasa* casa;
    int i;

    if(disponibles!=NULL && vendidas!=NULL)
    {
        archD = fopen("disponibles.csv", "w");
        fprintf(archD, "ID,DIR,AMB,PRECIO\n");
        for(i=0; i< disponibles->len(disponibles); i++)
        {
            casa = disponibles->get(disponibles, i);
            fprintf(archD, "%d,%s,%d,%.2f\n", casa->id, casa->direccion, casa->ambientes, casa->precio);
        }

        archV = fopen("vendidas.csv", "w");
        fprintf(archV, "ID,DIR,AMB,PRECIO\n");
        for(i=0; i< vendidas->len(vendidas); i++)
        {
            casa = vendidas->get(vendidas, i);
            fprintf(archV, "%d,%s,%d,%.2f\n", casa->id, casa->direccion, casa->ambientes, casa->precio);
        }


        fclose(archD);
        fclose(archV);
    }
}

void leerArchivoDisp(ArrayList* lista)
{
    FILE* archivo;
    eCasa* casa;
    char matriz[4][120];

    if(lista!=NULL)
    {
        if((archivo = fopen("disponibles.csv", "r")) == NULL)
        {
            if((archivo = fopen("disponibles.csv", "w")) == NULL)
            {
                printf("No se pudo generar el archivo de casas disponibles.\n");
            }
        }
        else
        {
            fscanf(archivo, "%[^,],%[^,],%[^,],%[^\n]\n", matriz[0], matriz[1], matriz[2], matriz[3]);
            while(!feof(archivo))
            {
                fscanf(archivo, "%[^,],%[^,],%[^,],%[^\n]\n", matriz[0], matriz[1], matriz[2], matriz[3]);
                casa = newCasaParam(matriz[1], atoi(matriz[2]), atof(matriz[3]), atoi(matriz[0]));
                if(casa!=NULL)
                {
                    lista->add(lista, casa);
//                    printf("Disp\n");
//                    printCasa(casa);
                }
            }
            printf("Se cargaron %d casas disponibles.\n", lista->len(lista));
        }
        fclose(archivo);
    }
}

void leerArchivoVendidas(ArrayList* lista)
{
    FILE* archivo;
    eCasa* casa;
    char matriz[4][120];

    if(lista!=NULL)
    {
        if((archivo = fopen("vendidas.csv", "r")) == NULL)
        {
            if((archivo = fopen("vendidas.csv", "w")) == NULL)
            {
                printf("No se pudo generar el archivo de casas vendidas.\n");
            }
        }
        else
        {
            fscanf(archivo, "%[^,],%[^,],%[^,],%[^\n]\n", matriz[0], matriz[1], matriz[2], matriz[3]);
            while(!feof(archivo))
            {
                fscanf(archivo, "%[^,],%[^,],%[^,],%[^\n]\n", matriz[0], matriz[1], matriz[2], matriz[3]);
                casa = newCasaParam(matriz[1], atoi(matriz[2]), atof(matriz[3]), atoi(matriz[0]));
                if(casa!=NULL)
                {
                    lista->add(lista, casa);
//                    printf("Vend\n");
//                    printCasa(casa);
                }
            }
            printf("Se cargaron %d casas vendidas.\n", lista->len(lista));
        }

        fclose(archivo);
    }
}


void hardcodeaCasasD(ArrayList* lista)
{
    eCasa* casa1 = newCasaParam("aaa 111", 3, 200000, 1111);
    eCasa* casa2 = newCasaParam("bbb 222", 2, 150000, 2222);
    eCasa* casa3 = newCasaParam("ccc 333", 3, 500000, 3333);
    eCasa* casa4 = newCasaParam("ddd 444", 5, 1500000, 4444);
    eCasa* casa5 = newCasaParam("eee 555", 1, 20000, 5555);
    eCasa* casa6 = newCasaParam("fff 666", 2, 170000, 6666);

    lista->add(lista, casa1);
    lista->add(lista, casa2);
    lista->add(lista, casa3);
    lista->add(lista, casa4);
    lista->add(lista, casa5);
    lista->add(lista, casa6);
}
