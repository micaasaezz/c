typedef struct
{
    int id;
    char direccion[100];
    int ambientes;
    float precio;

} eCasa;

int menu();

eCasa* newCasa();
eCasa* newCasaParam(char dir[], int ambientes, float precio, int id);

void agregarCasa(ArrayList* lista);

void printCasa(eCasa* casa);

eCasa* buscaCasaPorId(ArrayList* lista, int id);

void agregarVendida(eCasa* casa, ArrayList* disponibles, ArrayList* vendidas);

void listas(ArrayList* disponibles, ArrayList* vendidas);

void cargarArchivos(ArrayList* disponibles, ArrayList* vendidas);
void leerArchivoDisp(ArrayList* lista);
void leerArchivoVendidas(ArrayList* lista);


void hardcodeaCasasD(ArrayList* lista);
