

void mostrarDatos(int[], char[][15], int[],  int);
void cargarDatos(int[], char[][15], int[],  int);
void bajaDatos(int[], char[][15], int[],  int);
void modificarDatos(int[], char[][15], int[],  int);
void ordenarPorNombre(int[], char[][15], int[],  int);
