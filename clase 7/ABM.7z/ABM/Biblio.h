

void mostrarDatos(int[], char[][15],  int);
void cargarDatos(int[], char[][15],  int);
void ordenarPorNombre(int[], char[][15],  int);
