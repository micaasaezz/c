<?php
include("Verificadora.php");

<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

require_once './vendor/autoload.php';
require_once 'usuario.php';

$app = new \Slim\App(["settings" => $config]);

$app->get('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>GET");
    return $response;
});

$app->post('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>POST");
    return $response;
});
$app->put('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>PUT");
    return $response;
});
$app->delete('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>DELETE");
    return $response;
});

$app->add(\Verificadora::class."::ValidarUsuario");


$app->run();


?>

?>