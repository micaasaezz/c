<?php
require("IMiddleware.php");
class Verificadora implements IMiddleware
{
    static function VerificarUsuario($request, $response, $next)
    {
        if($request->isGet())
        {
            $response->getBody()->write("<br>El request es un GET");
        }
        else if ($request->isPost())
        {
            $respuestasArray = $request->GetParsedBody();
        
            require_once("AccesoDatos.php");
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuarios".
                                            "WHERE nombre=:nombre and clave=:clave and perfil=:perfil");
            
            $nombre = $respuestasArray["nombre"];
            $perfil = $respuestasArray["perfil"];
            $clave = $respuestasArray["clave"];
            $consulta->bindParam(":nombre", $nombre, PDO::PARAM_STR);
            $consulta->bindParam(":clave", $clave, PDO::PARAM_STR);
            $consulta->bindParam(":perfil", $perfil, PDO::PARAM_STR);
            $consulta->Execute();
            $usuarios = $consulta->Fetch();
                
            if ($usuarios > 0) 
            {
                $response->getBody()->write("<br>Bienvenidx ". $nombre);  
                $response->getBody()->write("<br>El request es un POST");
                return $next($request,$response);
            }
            else
            {
                $response->getBody()->write("<br>Sin permiso/no registrado en base de datos");
            }
        }
    }
}
?>