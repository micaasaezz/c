#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "arraylist.h"
#include "funciones.h"

int main()
{
    ArrayList* listaUsuarios = al_newArrayList();
    eUsuario* usuarioAux = newUsuario();

    ArrayList* comentarios = al_newArrayList();
    //eComentario* coment = newComentario();

    char seguir = 's';
    int opcion;
    int auxInt;

    leerArchivos(listaUsuarios, comentarios);

    while(seguir=='s')
    {
       printf("1- Alta de usuario.\n");
       printf("2- Modificar datos de usuario.\n");
       printf("3- Baja de un usuario.\n");
       printf("4- Nuevo comentario.\n");
       printf("5- Nuevo 'me gusta'.\n");
       printf("6- Informes.\n");
       printf("7- Salir.\n");

       scanf("%d", &opcion);

       switch(opcion)
       {
            case 1:
                altaUsuario(listaUsuarios);
                guardaUsuariosEnArchivo(listaUsuarios);
                break;

            case 2:
                if(listaUsuarios->isEmpty(listaUsuarios) == 1)
                {
                    printf("No hay usuarios para modificar!\n");
                }
                else{
                    usuarioAux = buscaNick(listaUsuarios);
                    if(usuarioAux!=NULL)
                    {
                        modificarUsuario(listaUsuarios,usuarioAux);
                        guardaUsuariosEnArchivo(listaUsuarios);
                    }
                    else
                    {
                        printf("No se encontro ese nick!\n");
                    }
                }
                 break;

            case 3:
                if(listaUsuarios->isEmpty(listaUsuarios) == 1)
                {
                    printf("No hay usuarios para borrar!\n");
                }
                else{
                    usuarioAux = buscaNick(listaUsuarios);
                    if(usuarioAux!=NULL)
                    {
                        auxInt = bajaUsuario(listaUsuarios, usuarioAux);
                        if(auxInt != 0)
                        {
                            printf("No se pudo borrar al usuario!\n");
                            break;
                        }
                        guardaUsuariosEnArchivo(listaUsuarios);
                    }
                    else
                    {
                        printf("No se encontro ese nick!\n");
                    }
                }
                break;

            case 4:
                if(listaUsuarios->isEmpty(listaUsuarios) == 1)
                {
                    printf("No hay usuarios para realizar comentarios!\n");
                }
                else{
                    usuarioAux = buscaNick(listaUsuarios);
                    if(usuarioAux!=NULL)
                    {
                        printf("Ingrese su clave de acceso: ");
                        fflush(stdin);
                        gets(usuarioAux->password);
                        if(buscaClave(listaUsuarios, usuarioAux) == 0)
                        {
                            comentar(usuarioAux, comentarios);
                            guardaComentariosEnArchivo(comentarios);
                            break;
                        }
                        else
                        {
                            printf("Clave incorrecta!\n");
                        }
                    }
                    else
                    {
                        printf("No se encontro ese nick!\n");
                    }
                }


                break;

            case 5:
                if(listaUsuarios->isEmpty(listaUsuarios) == 1)
                {
                    printf("No hay usuarios registrados!\n");
                }
                else if(comentarios->isEmpty(comentarios) == 1)
                {
                    printf("No hay comentarios disponibles!\n");

                }
                else{
                    usuarioAux = buscaNick(listaUsuarios);
                    if(usuarioAux!=NULL)
                    {
                        printf("Ingrese su clave de acceso: ");
                        fflush(stdin);
                        gets(usuarioAux->password);
                        if(buscaClave(listaUsuarios, usuarioAux) == 0)
                        {
                            darMeGusta(comentarios);
                            guardaComentariosEnArchivo(comentarios);
                        }
                        else
                        {
                            printf("Clave incorrecta!\n");
                        }
                    }
                    else
                    {
                        printf("No se encontro ese nick!\n");
                    }
                }

                break;

            case 6:
                if(listaUsuarios->isEmpty(listaUsuarios) == 1)
                {
                    printf("No hay usuarios registrados!\n\n");
                    if(comentarios->isEmpty(comentarios) == 0)
                    {
                        listarComentarios(comentarios);
                    }
                }
                else if(comentarios->isEmpty(comentarios) == 1)
                {
                    printf("No hay comentarios disponibles!\n\n");
                    if(listaUsuarios->isEmpty(listaUsuarios) == 0)
                    {
                        listarUsuarios(listaUsuarios);
                    }
                }
                else
                {
                    printf("\n1- Usuarios.\n2- Comentarios.\n3- Ambos.\n");
                    scanf("%d", &auxInt);
                    switch(auxInt)
                    {
                        case 1:
                            listarUsuarios(listaUsuarios);
                            break;

                        case 2:
                            listarComentarios(comentarios);
                            break;

                        case 3:
                            listarUsuarios(listaUsuarios);
                            listarComentarios(comentarios);
                            break;

                        default:
                            printf("Error, accion cancelada!\n");
                            break;
                    }
                }
                break;

            case 7:
                seguir = 'n';
                break;

            default:
                printf("Error opcion no valida!\n");
                break;
       }

       system("pause");
       system("cls");

    }
    return 0;
}
