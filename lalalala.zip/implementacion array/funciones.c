#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include "arraylist.h"
#include "funciones.h"

#define IDCOMENT 1000

eUsuario* newUsuario()
{
    eUsuario* usuario = NULL;
    usuario = (eUsuario*) malloc(sizeof(eUsuario));

    return usuario;
}

eComentario* newComentario()
{
    eComentario* coment = NULL;
    coment = (eComentario*) malloc(sizeof(eComentario));
    if(coment != NULL)
    {
        coment->contMG = 0;
    }

    return coment;
}

void altaUsuario(ArrayList* lista)
{
    eUsuario* usuario;
    eUsuario* aux;
    usuario = newUsuario();
    aux = newUsuario();
    int auxRet, i;

    if(usuario!=NULL)
    {
        do
        {
            auxRet = getString(usuario->nombre, "Ingrese su nombre: ", "Tama�o posible de 2 a 30 caracteres!\n", 2, 30);

        }
        while(auxRet == -1);

        do
        {
            auxRet = getString(usuario->userName, "Ingrese su nick: ", "Tama�o posible de 4 a 20 caracteres!\n", 4, 20);
            for(i=0; i<lista->len(lista); i++)
            {
                aux = lista->get(lista, i);
                if(strcmp(aux->userName, usuario->userName) == 0)
                {
                    printf("Nick ocupado.\n");
                    auxRet = -1;
                    break;
                }
            }
        }
        while(auxRet == -1);

        do
        {
            auxRet = getString(usuario->password, "Ingrese su clave de acceso: ", "Tama�o posible 8 caracteres!\n", 7, 9);

        }
        while(auxRet == -1);

        do
        {
            auxRet = getString(usuario->email, "Ingrese su email: ", "Tama�o posible de 10 a 50 caracteres!\n", 9, 50);

        }
        while(auxRet == -1);

        auxRet = lista->add(lista, usuario);
        if(auxRet == 0)
        {
            printf("Usuario registrado correctamente.\n");
        }
        else
        {
            printf("No se pudo registrar el usuario!\n");
        }

    }


}

int getString(char* input,char message[],char errorMessage[], int lowLimit, int hiLimit)
{
    int respuesta = 0;
    int pudoLeer;

    if(input == NULL)
    {
        respuesta = -1;
        return respuesta;
    }

    printf("%s", message);
    fflush(stdin);
    pudoLeer = scanf("%s", input);
    if(pudoLeer == 0)
    {
        respuesta = -1;
    }
    else if(strlen(input) > hiLimit || strlen(input) < lowLimit)
    {
        printf("%s", errorMessage);
        respuesta = -1;
    }

    return respuesta;
}



void modificarUsuario(ArrayList* lista, eUsuario* usuario)
{
    int opcion, auxint, auxRet;
    char nombre[30];
    char password[10];
    char email[50];
    eUsuario* aux = newUsuario();
    char rta;

    printf("Elija campo a modificar: \n1- nombre.\t2- email.\t3- clave de acceso. ");
    scanf("%d", &opcion);
    switch(opcion)
    {
    case 1:
        do
        {
            auxRet = getString(nombre, "Ingrese su nuevo nombre: ", "Tama�o posible de 2 a 30 caracteres!\n", 2, 30);

        }
        while(auxRet == -1);
        auxint = lista->indexOf(lista, usuario);
        aux = lista->get(lista, auxint);
        printf("Desea cambiar este nombre (%s) por este (%s)?  (s/n)\n", aux->nombre, nombre);
        //scanf("%c", &rta);
        rta = getche();
        if(rta == 's' || rta == 'S')
        {
            strcpy(aux->nombre, nombre);
            auxRet = lista->push(lista, auxint, aux);
            if(auxRet == 0)
            {
                printf("Se cambio el nombre correctamente!\n");
            }
            else
            {
                printf("No se pudo cambiar el nombre.\n");
            }
        }
        else
        {
            printf("Cambio cancelado!\n");
        }
        break;

    case 2:
        do
        {
            auxRet = getString(email, "Ingrese el nuevo email: ", "Tama�o posible de 10 a 50 caracteres!\n", 9, 50);

        }
        while(auxRet == -1);

        auxint = lista->indexOf(lista, usuario);
        aux = lista->get(lista, auxint);
        printf("Desea cambiar este email (%s) por este (%s) ?  (s/n)\n", aux->email, email);
        //scanf("%c", &rta);
        rta = getche();
        if(rta == 's' || rta == 'S')
        {
            strcpy(aux->email, email);
            auxRet = lista->push(lista, auxint, aux);
            if(auxRet == 0)
            {
                printf("Se cambio el email correctamente!\n");
            }
            else
            {
                printf("No se pudo cambiar el email.\n");
            }
        }
        else
        {
            printf("Cambio cancelado!\n");
        }

        break;


    case 3:
        do
        {
            auxRet = getString(password, "Ingrese su clave de acceso: ", "Tama�o posible 8 caracteres!\n", 7, 9);

        }
        while(auxRet == -1);

        auxint = lista->indexOf(lista, usuario);
        aux = lista->get(lista, auxint);
        if(strcmp(password, aux->password) == 0)
        {
            do
            {
                auxRet = getString(password, "Ingrese su nueva clave de acceso: ", "Tama�o posible 8 caracteres!\n", 7, 9);

            }
            while(auxRet == -1);

            printf("\nEsta seguro de cambiar su clave? (s/n) ");
            //scanf("%c", &rta);
            rta = getche();
            if(rta == 's' || rta == 'S')
            {
                strcpy(aux->password, password);
                auxRet = lista->push(lista, auxint, aux);
                if(auxRet == 0)
                {
                    printf("Se cambio la clave correctamente!\n");
                }
                else
                {
                    printf("No se pudo cambiar la clave.\n");
                }
            }
            else
            {
                printf("Cambio cancelado!\n");
            }

        }
        else
        {
            printf("Clave incorrecta!\n");

        }


        break;

    default:
        printf("Error opcion invalida!\n");
        break;
    }
}

eUsuario* buscaNick(ArrayList* lista)
{
    eUsuario* usuario;
    eUsuario* retUsuario = NULL;
    usuario = newUsuario();
    int auxRet = -1;
    int i;
    char auxNick[20];


    while(auxRet == -1)
    {
        auxRet = getString(auxNick, "Ingrese su nick: ", "Tama�o posible de 4 a 20 caracteres!\n", 4, 20);

        if(auxRet!=-1)
        {
            for(i=0; i<lista->len(lista); i++)
            {
                usuario = lista->get(lista, i);
                if(strcmp(usuario->userName, auxNick) == 0)
                {
                    retUsuario = newUsuario();
                    retUsuario = usuario;
                    auxRet = 0;
                    break;
                }
            }
        }
    }

    return retUsuario;
}

int bajaUsuario(ArrayList* lista, eUsuario* usuario)
{
    int returnAux = -1;
    int auxInt;
    char rta;

    if(lista!=NULL && usuario!=NULL)
    {
        printf("Esta seguro que desea borrar a %s ? (s/n) ", usuario->nombre);
        rta = getche();
        if(rta == 's' || rta == 'S')
        {
            auxInt = lista->indexOf(lista, usuario);
            if(auxInt != -1)
            {
                if(!lista->remove(lista, auxInt))
                {
                    printf("Se borro correctamente al usuario.\n");
                    returnAux = 0;
                }
            }
        }
    }

    return returnAux;
}



int buscaClave(ArrayList* lista, eUsuario* usuario)
{
    int returnAux = -1;
    int i;
    eUsuario* aux = newUsuario();

    if(lista!=NULL && usuario!=NULL)
    {
        for(i=0; i<lista->len(lista); i++)
        {
            aux = lista->get(lista, i);

            if(strcmp(usuario->password, aux->password) == 0)
            {
                returnAux = 0;
                break;
            }
        }
    }

    return returnAux;
}


void comentar(eUsuario* usuario, ArrayList* comentarios)
{
    int auxRet;
    char rta;
    eComentario* comentario = newComentario();
    do
    {
        auxRet = getString(comentario->texto, "Ingrese su comentario: ", "Tama�o maximo 140 caracteres!\n", 0, 140);

    }
    while(auxRet == -1);

    printf("\nEsta seguro que desea publicar ese comentario? (s/n) ");
    rta = getche();
    if(rta == 's' || rta == 'S')
    {
        strcpy(comentario->autor, usuario->userName);
        comentario->idComent = (IDCOMENT + comentarios->len(comentarios));
        auxRet = comentarios->add(comentarios, comentario);
        if(auxRet == 0)
        {
            printf("Comentario registrado correctamente.\n");
        }
        else
        {
            printf("No se pudo guardar el comentario!\n");
        }
    }
    else
    {
        printf("Comentario cancelado!\n");
    }

}


void darMeGusta(ArrayList* comentarios)
{
    int i;
    int opcion;
    int auxInt=-1;
    eComentario* comentAux = newComentario();

    printf("Ingrese el id del comentario que desea darle 'me gusta' , o '0' (cero) para ver una lista de comentarios disponibles:\n");
    scanf("%d", &opcion);
    if(opcion == 0)
    {
        printf("(ID - COMENTARIO)\n");
        for(i=0; i< comentarios->len(comentarios); i++)
        {
            comentAux = comentarios->get(comentarios, i);
            printf("%d - %s\n", comentAux->idComent, comentAux->texto);
        }

        printf("\nIngrese el id del comentario que desea darle 'me gusta' , o '0' (cero) para cancelar:\n");
        scanf("%d", &opcion);
        if(opcion == 0)
        {
            printf("Cancelado!\n");
            auxInt = 0;
        }
        else
        {
             for(i=0; i< comentarios->len(comentarios); i++)
            {
                comentAux = comentarios->get(comentarios, i);

                if(comentAux->idComent == opcion)
                {
                    comentAux->contMG++;
                    printf("Su 'me gusta' se registro correctamente.\nEste comentario ahora tiene %d 'me gusta'.\n", comentAux->contMG);
                    auxInt = 0;
                    break;
                }
            }
        }
    }
    else
    {
        for(i=0; i< comentarios->len(comentarios); i++)
            {
                comentAux = comentarios->get(comentarios, i);

                if(comentAux->idComent == opcion)
                {
                    comentAux->contMG++;
                    printf("Su 'me gusta' se registro correctamente.\nEste comentario ahora tiene %d 'me gusta'.\n", comentAux->contMG);

                    auxInt = 0;
                    break;
                }
            }
    }


    if(auxInt == -1)
    {
        printf("Id no valido. Operacion cancelada!\n");
    }

}
int comparaUsuariosPorNombre(void* usuarioA, void* usuarioB)
{
    int returnAux;

    eUsuario* userA = (eUsuario*) usuarioA;
    eUsuario* userB = (eUsuario*) usuarioB;

    returnAux = strcmp(userA->nombre, userB->nombre);

    return returnAux;
}

int comparaUsuariosPorNickname(void* usuarioA, void* usuarioB)
{
    int returnAux;

    eUsuario* userA = (eUsuario*) usuarioA;
    eUsuario* userB = (eUsuario*) usuarioB;

    returnAux = strcmp(userA->userName, userB->userName);

    return returnAux;
}

void listarUsuarios(ArrayList* usuarios)
{
    int opcion, i, auxInt;
    eUsuario* auxUs = newUsuario();

    if(usuarios!=NULL)
    {
        printf("Elija lo que quiere ver:\n1- Lista de usuarios ordenada por nombre.\n2- Lista de usuarios ordenada por username.\n3- Cancelar.\n");
        scanf("%d", &opcion);
        switch(opcion)
        {
            case 1:
                printf("\nNombre\tNick\temail\n");
                for(i=0; i< usuarios->len(usuarios); i++)
                {
                    auxInt = usuarios->sort(usuarios, comparaUsuariosPorNombre, 1);
                    if(auxInt == -1)
                    {
                        printf("No se pudo ordenar!\n");
                        break;
                    }
                    auxUs = usuarios->get(usuarios, i);
                    printf("%s\t%s,%s\n", auxUs->nombre, auxUs->userName, auxUs->email);
                }
                break;

            case 2:
                printf("\nNick\tNombre\temail\n");
                for(i=0; i< usuarios->len(usuarios); i++)
                {
                    auxInt = usuarios->sort(usuarios, comparaUsuariosPorNickname, 1);
                    if(auxInt == -1)
                    {
                        printf("No se pudo ordenar!\n");
                        break;
                    }
                    auxUs = usuarios->get(usuarios, i);
                    printf("%s\t%s,%s\n", auxUs->userName, auxUs->nombre, auxUs->email);
                }
                break;

            case 3:
                printf("Cancelado!\n");
                break;

            default:
                printf("Opcion incorrecta. Accion cancelada!\n");
                break;
        }
    }

}

void listarComentarios(ArrayList* comentarios)
{
    int opcion, i;
    eComentario* comentAux = newComentario();
    eComentario* comentMG = newComentario();

    printf("Elija lo que quiere ver:\n1- Cantidad de comentarios.\n2- Comentario con mas 'me gusta'.\n3- Cancelar.\n");
    scanf("%d", &opcion);
    switch(opcion)
    {
        case 1:
            printf("La cantidad actual de comentarios es: %d\n", comentarios->len(comentarios));
            break;

        case 2:
            for(i=0; i< comentarios->len(comentarios); i++)
            {
                comentAux = comentarios->get(comentarios, i);
                if(comentAux->contMG > comentMG->contMG)
                {
                    comentMG = comentAux;
                }
            }
            if(comentMG->contMG > 0)
            {
                printf("El comentario con mas 'me gusta' es:\n%s\ncomentario hecho por: %s\ncant de 'me gusta': %d\n", comentMG->texto, comentMG->autor, comentMG->contMG);
            }
            else
            {
                printf("Todos los comentarios tienen cero 'me gusta'.\n");
            }
            break;

        case 3:
            printf("Cancelado!\n");
            break;

        default:
            printf("Opcion incorrecta. Accion cancelada!\n");
            break;
    }

}


void guardaUsuariosEnArchivo(ArrayList* usuarios)
{
    FILE* archUsuarios;
    eUsuario* usuarioAux;

    int i, auxInt, largo=0;

    if(usuarios!=NULL)
    {
        if((archUsuarios=fopen("usuarios.csv", "w")) == NULL)
        {
            printf("No se pudo crear el archivo de usuarios!\n");
        }
        else
        {
            for(i=0; i< usuarios->len(usuarios); i++)
            {
                usuarioAux = usuarios->get(usuarios, i);
                auxInt = fprintf(archUsuarios, "%s,%s,%s,%s\n", usuarioAux->userName, usuarioAux->nombre, usuarioAux->password, usuarioAux->email);
                largo = strlen(usuarioAux->userName);
                largo+=strlen(usuarioAux->nombre);
                largo+=strlen(usuarioAux->password);
                largo+=strlen(usuarioAux->email);
                largo+=4; //comas y \n
                if(auxInt != largo)
                {
                    printf("Hubo un error al guardar los usuarios en el archivo!\n");
                }
            }

        }
        fclose(archUsuarios);
    }



}


void guardaComentariosEnArchivo(ArrayList* comentarios)
{
    FILE* archComentarios;
    eComentario* comentAux;
    int i, auxInt;

    if(comentarios!=NULL)
    {
        if((archComentarios=fopen("comentarios.dat", "wb")) ==NULL)
        {
            printf("No se pudo crear el archivo de comentarios!\n");
        }
        else
        {
            for(i=0; i< comentarios->len(comentarios); i++)
            {
                comentAux = comentarios->get(comentarios, i);
                auxInt = fwrite(comentAux, sizeof(eComentario), 1, archComentarios);
                if(auxInt!=1)
                {
                    printf("Hubo un error al guardar los comentarios en el archivo!\n");
                }
            }
        }
        fclose(archComentarios);
    }


}



void leerArchivos(ArrayList* usuarios, ArrayList* comentarios)
{
    FILE* archUsuarios;
    FILE* archComents;
    int auxInt;
    eUsuario* usAux;
    char matrizAux[4][1000];
    eComentario* comentAux;

    if(usuarios!=NULL)
    {
        if((archUsuarios = fopen("usuarios.csv", "r"))==NULL)
        {
            if((archUsuarios = fopen("usuarios.csv", "w"))==NULL)
            {
                printf("No se pudo generar el archivo de usuarios!\n");
            }

        }
        else
        {
            while(!feof(archUsuarios))
            {
                fscanf(archUsuarios, "%[^,],%[^,],%[^,],%[^\n]", matrizAux[0], matrizAux[1], matrizAux[2], matrizAux[3]);
                usAux = newUsuario();
                strcpy(usAux->userName, matrizAux[0]);
                strcpy(usAux->nombre, matrizAux[1]);
                strcpy(usAux->password, matrizAux[2]);
                strcpy(usAux->email, matrizAux[3]);

               usuarios->add(usuarios, usAux);
           }
        }
        fclose(archUsuarios);

    }
    else
    {
        printf("No se pudo leer el archivo, lista de usuarios nula!\n");
    }

    if(comentarios!=NULL)
    {
        if((archComents = fopen("comentarios.dat", "rb"))==NULL)
        {
            if((archComents = fopen("comentarios.dat", "wb"))==NULL)
            {
                printf("No se pudo generar el archivo de comentarios!\n");
            }

        }
        else
        {
            while(!feof(archUsuarios))
            {
                comentAux = newComentario();
                auxInt = fread(comentAux, sizeof(eComentario), 1, archComents);
                if(auxInt==1)
                {
                    auxInt = comentarios->add(comentarios, comentAux);
//                    if(auxInt!=1)
//                    {
//                        printf("No se pudo leer un comentario!\n");
//                    }
                }
            }
        }
        fclose(archComents);

    }
    else
    {
        printf("No se pudo leer el archivo, lista de comentarios nula!\n");
    }

}







