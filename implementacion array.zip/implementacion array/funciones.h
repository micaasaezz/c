
typedef struct
{
    char userName[20];
    char nombre[30];
    char password[10];
    char email[50];

}eUsuario;

typedef struct
{
    char texto[141];
    int idComent;
    int contMG;
    char autor[20]; //nickname del usuario que lo escribio

}eComentario;

eUsuario* newUsuario();
eComentario* newComentario();

void altaUsuario(ArrayList* lista);

int getString(char* input,char message[],char errorMessage[], int lowLimit, int hiLimit);

void modificarUsuario(ArrayList* lista, eUsuario* usuario);

eUsuario* buscaNick(ArrayList* lista);

int bajaUsuario(ArrayList* lista, eUsuario* usuario);

int buscaClave(ArrayList* lista, eUsuario* usuario);

void comentar(eUsuario* usuario, ArrayList* comentarios);

void darMeGusta(ArrayList* comentarios);

char* getPassword(eUsuario* usuario);

int getIdComent(eComentario* comentario);

void listarUsuarios(ArrayList* usuarios);

int comparaUsuariosPorNombre(void* usuarioA, void* usuarioB);
int comparaUsuariosPorNickname(void* usuarioA, void* usuarioB);

void listarComentarios(ArrayList* comentarios);

void guardaUsuariosEnArchivo(ArrayList* usuarios);
void guardaComentariosEnArchivo(ArrayList* comentarios);
