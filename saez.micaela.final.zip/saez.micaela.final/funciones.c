#include <stdio.h>
#include <stdlib.h>
#include <conio.h> // getche()
#include <ctype.h> // to lower- to upper   ej de uso: rta=tolower(getche());
#include <string.h>
#include "funciones.h"
#include "arraylist.h"


int menu()
{
    int opcion=0;

    printf("1- Leer tickets.\n");
    printf("2- Procesar informacion.\n");
    printf("3- Mostrar estadisticas.\n");
    printf("4- Salir.\n");
    scanf("%d",&opcion);

    return opcion;
}

eTicket* newTicket()
{
    eTicket* aux;
    aux = (eTicket*) malloc(sizeof(eTicket));
    return aux;
}
eProblema* newProblema()
{
    eProblema* aux;
    aux = (eProblema*) malloc(sizeof(eProblema));
    return aux;
}
eTicket* newTicketPar(char fecha[], char hora[], int idProblema, int gravedad, char mensaje[])
{
    eTicket* auxTick;
    auxTick = newTicket();
    if(auxTick!=NULL)
    {
        strcpy(auxTick->fecha, fecha);
        strcpy(auxTick->hora, hora);
        auxTick->idProblema = idProblema;
        auxTick->gravedad = gravedad;
        strcpy(auxTick->mensaje, mensaje);
    }
    return auxTick;
}
eProblema* newProblemaPar(int id, char nombre[], char email[])
{
    eProblema* auxProblema;
    auxProblema = newProblema();
    if(auxProblema!=NULL)
    {
        auxProblema->id = id;
        strcpy(auxProblema->nombre, nombre);
        strcpy(auxProblema->email, email);
    }
    return auxProblema;
}


void leerArchivo(ArrayList* tickets, ArrayList* problemas)
{
    FILE* archTick;
    FILE* archProblems;
    char mat[5][120];
    eTicket* auxTicket;
    eProblema* auxProblema;

    if(tickets!=NULL)
    {
        if( (archTick = fopen("ticket.txt", "r")) == NULL)
        {
            if( (archTick = fopen("ticket.txt", "w")) == NULL)
            {
                printf("No se pudo generar el archivo!\n");
            }
        }
        else
        {
            while(!feof(archTick))
            {
                fscanf(archTick, "%[^;];%[^;];%[^;];%[^;];%[^\n]\n", mat[0], mat[1], mat[2], mat[3], mat[4]);

                auxTicket = newTicketPar(mat[0], mat[1], atoi(mat[2]), atoi(mat[3]), mat[4]);

                if(auxTicket!=NULL)
                {
                    tickets->add(tickets, auxTicket);
                }
            }
            printf("Se cargaron %d tickets.\n", tickets->len(tickets));
        }

        fclose(archTick);
    }
    if(problemas!=NULL)
    {
        if( (archProblems = fopen("problemas.txt", "r")) == NULL)
        {
            if( (archProblems = fopen("problemas.txt", "w")) == NULL)
            {
                printf("No se pudo generar el archivo!\n");
            }
        }
        else
        {
            while(!feof(archProblems))
            {
                fscanf(archProblems, "%[^;];%[^;];%[^\n]\n", mat[0], mat[1], mat[2]);

                auxProblema = newProblemaPar(atoi(mat[0]), mat[1], mat[2]);

                if(auxProblema!=NULL)
                {
                    problemas->add(problemas, auxProblema);
                }
            }
            printf("Se cargaron %d problemas.\n", problemas->len(problemas));
        }

        fclose(archProblems);
    }
}



void cargarArchivo(ArrayList* tickets, ArrayList* problemas)
{
    FILE* archTickets;
    FILE* archProblemas;
    int i;
    eTicket* auxTicket;
    eProblema* auxProblema;

    if(tickets!=NULL)
    {
        archTickets = fopen("ticket.txt", "w");
        for(i=0; i<tickets->len(tickets); i++)
        {
            auxTicket = tickets->get(tickets, i);
            fprintf(archTickets, "%s;%s;%d;%d;%s\n", auxTicket->fecha, auxTicket->hora, auxTicket->idProblema, auxTicket->gravedad, auxTicket->mensaje);
        }
        fclose(archTickets);
    }

    if(problemas!=NULL)
    {
        archProblemas = fopen("problemas.txt", "w");
        for(i=0; i<problemas->len(problemas); i++)
        {
            auxProblema = problemas->get(problemas, i);
            fprintf(archProblemas, "%d;%s;%s\n", auxProblema->id, auxProblema->nombre, auxProblema->email);
        }
       fclose(archProblemas);
    }

}

void cargarArchivoSolucionar(eProblema* problema, eTicket* ticket)
{
    FILE* archivo;

    if((archivo = fopen("solucionar.txt", "a")) == NULL)
    {
        printf("No se pudo generar el archivo!\n");
    }
    else
    {
        fprintf(archivo, "%s;%s;%s;%s\n", ticket->fecha, ticket->hora, problema->nombre, ticket->mensaje);
    }

    fclose(archivo);
}
void cargarArchivoUrgentes(eProblema* problema, eTicket* ticket)
{
    FILE* archivo;

    if( (archivo = fopen("solucionarUrgente.txt", "a")) == NULL)
    {
        printf("No se pudo generar el archivo!\n");
    }
    else
    {
        fprintf(archivo, "%s;%s;%s;%s\n", ticket->fecha, ticket->hora, problema->nombre, ticket->mensaje);
    }

    fclose(archivo);
}

void printUrgente(eProblema* problema, eTicket* ticket)
{
    printf("%s - %s - %s - %s - %s\n", ticket->fecha, ticket->hora, problema->nombre, ticket->mensaje, problema->email);
}

void procesarInf(ArrayList* tickets, ArrayList* problemas)
{
    eTicket* auxTicket;
    eProblema* auxProblema;
    int i, j;

    for(i=0; i< tickets->len(tickets); i++)
    {
        auxTicket = tickets->get(tickets, i);
        if(auxTicket->gravedad < 4)
        {
            continue;
        }
        else if(auxTicket->gravedad == 4 && auxTicket->idProblema != 3)
        {
           for(j=0; j< problemas->len(problemas); j++)
            {
                auxProblema = problemas->get(problemas, j);
                if(auxProblema->id == auxTicket->idProblema)
                {
                    cargarArchivoSolucionar(auxProblema, auxTicket);
                    break;
                }
            }

        }
        else if(auxTicket->gravedad >5 && auxTicket->gravedad < 9)
        {
            for(j=0; j< problemas->len(problemas); j++)
            {
                auxProblema = problemas->get(problemas, j);
                if(auxProblema->id == auxTicket->idProblema)
                {
                    cargarArchivoUrgentes(auxProblema, auxTicket);
                    break;
                }
            }

        }
        else if(auxTicket->gravedad >8)
        {
            for(j=0; j< problemas->len(problemas); j++)
            {
                auxProblema = problemas->get(problemas, j);
                if(auxProblema->id == auxTicket->idProblema)
                {
                    printUrgente(auxProblema, auxTicket);
                    break;
                }
            }

        }
    }

}

void mostrarEstadisticas(ArrayList* tickets, ArrayList* problemas)
{
    int menos3=0;
    int cont4=0;
    int cont5a8=0;
    int mas8=0;
    int i;
    eTicket* ticket;
//    eProblema* problem;

    for(i=0; i< tickets->len(tickets); i++)
    {
        ticket = tickets->get(tickets, i);
        if(ticket->gravedad < 3)
        {
            menos3++;
        }
        else if(ticket->gravedad == 4)
        {
            cont4++;
        }
        else if(ticket->gravedad >5 && ticket->gravedad <=8)
        {
            cont5a8++;
        }
        else if(ticket->gravedad >8)
        {
            mas8++;
        }
    }

    printf("GRAVEDAD MENOS A 3: %d\nGRAVEDAD 4: %d\nGRAVEDAD 5 A 8: %d\nGRAVEDAD MAYOR A 8: %d\n", menos3, cont4, cont5a8, mas8);


}
