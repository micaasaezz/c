#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "arraylist.h"

int main()
{
    int opcion;
    char seguir = 's';

    ArrayList* tickets = al_newArrayList();
    ArrayList* problemas = al_newArrayList();


    while(seguir == 's')
    {
        opcion = menu();
        switch(opcion)
        {
            case 1:
                leerArchivo(tickets, problemas);
                break;

            case 2:
                if(tickets->isEmpty(tickets) && problemas->isEmpty(problemas))
                {
                    printf("No hay elementos disponibles para realizar la accion!\n");
                }
                else
                {
                    procesarInf(tickets, problemas);
                }
                break;

            case 3:
                if(tickets->isEmpty(tickets) && problemas->isEmpty(problemas))
                {
                    printf("No hay elementos disponibles para realizar la accion!\n");
                }
                else
                {
                    mostrarEstadisticas(tickets, problemas);
                }
                break;

            case 4:
                seguir = 'n';
                break;

            default:
                printf("Error reingrese opcion!\n");
                break;
        }
        system("pause");
        system("cls");
    }
    return 0;
}
