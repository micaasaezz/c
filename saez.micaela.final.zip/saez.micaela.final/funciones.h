#include <stdio.h>
#include <stdlib.h>
#include "arraylist.h"
typedef struct
{
    char fecha[11];
    char hora[6];
    int idProblema;
    int gravedad;
    char mensaje[65];

} eTicket;

typedef struct
{
    int id;
    char nombre[33];
    char email[65];

} eProblema;

int menu();


eTicket* newTicket();
eProblema* newProblema();

eTicket* newTicketPar(char fecha[], char hora[], int idProblema, int gravedad, char mensaje[]);
eProblema* newProblemaPar(int id, char nombre[], char email[]);

void procesarInf(ArrayList* tickets, ArrayList* problemas);
void mostrarEstadisticas(ArrayList* tickets, ArrayList* problemas);

void cargarArchivoSolucionar(eProblema* problema, eTicket* ticket);
void cargarArchivoUrgentes(eProblema* problema, eTicket* ticket);

void printUrgente(eProblema* problema, eTicket* ticket);

void leerArchivo(ArrayList* tickets, ArrayList* problemas);
void cargarArchivo(ArrayList* tickets, ArrayList* problemas);

