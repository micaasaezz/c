#include <stdio.h>
#include <stdlib.h>
#include "arraylist.h"
typedef struct
{
    char letra;
    char nombre[22];
    int vocal;
    int consonante;

} eLetra;


int menu();

int getInt(int* input,char message[],char errorMessage[], int lowLimit, int hiLimit);
int getString(char* input,char message[],char errorMessage[], int lowLimit, int hiLimit);
int getFloat(float* input,char message[],char errorMessage[], float lowLimit, float hiLimit);


eLetra* newLetra();
eLetra* newLetraPar(char letra, char nombre[], int vocal, int consonante);

void printLetra(eLetra* letra);

void agregarLetra(ArrayList* lista);
void modificarLetra(ArrayList* lista);
void borrarLetra(ArrayList* lista);
void completar(ArrayList* lista);
int esVocal(eLetra* letra);
int esConsonante(eLetra* letra);
void comprobar(ArrayList* lista);
void listar(ArrayList* lista);


int ordenarPorLetra(void* l1, void* l2);

void leerArchivo(ArrayList* lista);
void cargarArchivo(ArrayList* lista);

