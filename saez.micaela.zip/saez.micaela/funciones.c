#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include "funciones.h"
#include "arraylist.h"


int menu()
{
    int opcion=0;

    printf("1- Agregar.\n");
    printf("2- Modificar.\n");
    printf("3- Baja.\n");
    printf("4- Completar.\n");
    printf("5- Comprobar.\n");
    printf("6- Generar y listar.\n");
    printf("7- Salir.\n");
    scanf("%d",&opcion);

    return opcion;
}


int getFloat(float* input,char message[],char errorMessage[], float lowLimit, float hiLimit)
{
    int respuesta = 0;
    int pudoLeer;

    if(input == NULL)
    {
        respuesta = -1;
        return respuesta;
    }
    fflush(stdin);
    printf("%s", message);
    pudoLeer = scanf("%f", input);
    if(pudoLeer == 0)
    {
        respuesta = -1;
    }
    else if(*input > hiLimit || *input < lowLimit)
    {
        printf("%s", errorMessage);
        respuesta = -1;
    }

    return respuesta;

}
int getInt(int* input,char message[],char errorMessage[], int lowLimit, int hiLimit)
{
    int respuesta = 0;
    int pudoLeer;

    if(input == NULL)
    {
        respuesta = -1;
        return respuesta;
    }
    fflush(stdin);
    printf("%s", message);
    pudoLeer = scanf("%d", input);
    if(pudoLeer == 0)
    {
        respuesta = -1;
    }
    else if(*input > hiLimit || *input < lowLimit)
    {
        printf("%s", errorMessage);
        respuesta = -1;
    }

    return respuesta;
}
int getString(char* input,char message[],char errorMessage[], int lowLimit, int hiLimit)
{
    int respuesta = 0;
    int pudoLeer;

    if(input == NULL)
    {
        respuesta = -1;
        return respuesta;
    }

    printf("%s", message);
    fflush(stdin);
    pudoLeer = scanf("%s", input);
    if(pudoLeer == 0)
    {
        respuesta = -1;
    }
    else if(strlen(input) > hiLimit || strlen(input) < lowLimit)
    {
        printf("%s", errorMessage);
        respuesta = -1;
    }

    return respuesta;
}

eLetra* newLetra()
{
    eLetra* ret;
    ret = (eLetra*) malloc(sizeof(eLetra));
    return ret;
}
eLetra* newLetraPar(char letra, char nombre[], int vocal, int consonante)
{
    eLetra* auxLetra;
    auxLetra = newLetra();
    if(auxLetra!=NULL)
    {
        auxLetra->letra = letra;
        strcpy(auxLetra->nombre, nombre);
        auxLetra->vocal = vocal;
        auxLetra->consonante = consonante;
    }
    return auxLetra;
}


void leerArchivo(ArrayList* lista)
{
    FILE* archivo;
    char mat[4][50];
    char letra;
    eLetra* auxLetra;

    if(lista!=NULL)
    {
        if( (archivo = fopen("datosSP.csv", "r")) == NULL)
        {
            if( (archivo = fopen("datosSP.csv", "w")) == NULL)
            {
                printf("No se pudo generar el archivo!\n");
            }
        }
        else
        {
            fscanf(archivo, &letra, mat[1], mat[2], mat[3]);

            while(!feof(archivo))
            {
                fscanf(archivo, "%[^,],%[^,],%[^,],%[^\n]\n", &letra, mat[1], mat[2], mat[3]);

                auxLetra = newLetraPar(letra, mat[1], atoi(mat[2]), atoi(mat[3]));

                if(auxLetra!=NULL)
                {
                    lista->add(lista, auxLetra);
                }
            }
            printf("Se cargaron %d elementos.\n", lista->len(lista));
        }

        fclose(archivo);
    }
}

void cargarArchivo(ArrayList* lista)
{
    FILE* archivo;
    int i;
    eLetra* auxLetra;

    archivo = fopen("datosSP.csv", "w");

    if(lista!=NULL)
    {
        fprintf(archivo, "letra,nombre,vocal,consonante\n");

        for(i=0; i<lista->len(lista); i++)
        {
            auxLetra = lista->get(lista, i);
            fprintf(archivo, "%c,%s,%d,%d\n", auxLetra->letra, auxLetra->nombre, auxLetra->vocal, auxLetra->consonante);
        }
    }

    fclose(archivo);
}


void printLetra(eLetra* letra)
{
    printf("%c - %s - %d - %d\n", letra->letra, letra->nombre, letra->vocal, letra->consonante);
}

void agregarLetra(ArrayList* lista)
{
    eLetra* auxLetra;
    char letra;
    char nombre[22];
    int auxInt;

    printf("Ingrese la letra: ");
    letra = tolower(getche());
    while(letra<'a' || letra>'z')
    {
        printf("Ingrese letra valida: ");
        letra = tolower(getche());
    }

    do
    {
        auxInt = getString(nombre, "Ingrese el nombre de la letra: ", "Entre 1 y 21 caracteres! Reingrese nombre: ", 1, 21);
    }while(auxInt == -1);

    auxLetra = newLetraPar(letra, nombre, 0, 0);
    if(auxLetra != NULL)
    {
        auxInt = lista->add(lista, auxLetra);
        if(auxInt == 0)
        {
            printf("Se agrego correctamente!\n");
        }
        else
        {
            printf("Error al agregar letra a la lista!\n");
        }
    }

}
void modificarLetra(ArrayList* lista)
{
    eLetra* auxLetra;
    char letra;
    int i, opcion=-1;
    char nombre[22];

    printf("Ingrese la letra a modificar: ");
    letra = tolower(getche());
    while(letra<'a' || letra>'z')
    {
        printf("Ingrese letra valida: ");
        letra = tolower(getche());
    }
    for(i=0; i< lista->len(lista); i++)
    {
        auxLetra = lista->get(lista, i);
        if(auxLetra->letra == letra)
        {
            printf("\n1. Letra\n2. Nombre\n");
            scanf("%d", &opcion);
            switch(opcion)
            {
                case 1:
                    printf("Ingrese la nueva letra: ");
                    letra = tolower(getche());
                    while(letra<'a' || letra>'z')
                    {
                        printf("Ingrese letra valida: ");
                        letra = tolower(getche());
                    }
                    auxLetra->letra = letra;
                    printf("\n");
                    printLetra(auxLetra);
                    printf("\nCambiado con exito!\n");
                    break;

                case 2:
                    do
                    {
                        i = getString(nombre, "Ingrese el nuevo nombre de la letra: ", "Entre 1 y 21 caracteres! Reingrese nombre: ", 1, 21);
                    }while(i == -1);
                    strcpy(auxLetra->nombre, nombre);
                    printf("\n");
                    printLetra(auxLetra);
                    printf("\nCambiado con exito!\n");
                    break;

                default:
                    printf("Opcion invalida, cancelado!\n");
                    break;
            }
            break;
        }
    }
    if(opcion == -1)
    {
        printf("No se encontro esa letra en la lista!\n");
    }

}

void borrarLetra(ArrayList* lista)
{
    eLetra* auxLetra;
    char letra;
    int i, auxInt=-2;


    printf("Ingrese la letra a borrar: ");
    letra = tolower(getche());
    while(letra<'a' || letra>'z')
    {
        printf("Ingrese letra valida: ");
        letra = tolower(getche());
    }
    for(i=0; i< lista->len(lista); i++)
    {
        auxLetra = lista->get(lista, i);
        if(auxLetra->letra == letra)
        {
            auxInt = lista->remove(lista, i);
            if(auxInt == 0)
            {
                printf("\nSe borro con exito!\n");
            }
            else
            {
                 printf("Error, no se pudo borrar!\n");
            }
            break;
        }
    }
    if(auxInt == -2)
    {
        printf("No se encontro esa letra en la lista!\n");
    }

}
int esVocal(eLetra* letra)
{
    int ret = -1;
    if(letra!=NULL)
    {
        if(letra->letra == 'a' || letra->letra == 'e' || letra->letra == 'i' || letra->letra == 'o' || letra->letra == 'u')
        {
            ret = 1;
        }
        else
        {
            ret = 0;
        }
    }
    return ret;
}
int esConsonante(eLetra* letra)
{
    int ret = -1;
    if(letra!=NULL)
    {
        if(letra->letra == 'a' || letra->letra == 'e' || letra->letra == 'i' || letra->letra == 'o' || letra->letra == 'u')
        {
            ret = 0;
        }
        else
        {
            ret = 1;
        }
    }
    return ret;
}

void completar(ArrayList* lista)
{
    eLetra* auxLetra;
    int i;
    //int cont=0;

    for(i=0; i<lista->len(lista); i++)
    {
        auxLetra = lista->get(lista, i);
        auxLetra->vocal = esVocal(auxLetra);
        auxLetra->consonante = esConsonante(auxLetra);
//        if(auxLetra->vocal!=-1 && auxLetra->consonante!=1)
//        {
//            cont++;
//        }
    }
    //printf("Se completaron los datos de %d letras.\n", cont);
}

int ordenarPorLetra(void* l1, void* l2)
{
    int ret;
    eLetra* letra1;
    eLetra* letra2;

    letra1 = (eLetra*) l1;
    letra2 = (eLetra*) l2;

    if(letra1->letra > letra2->letra)
    {
        ret = 1;
    }
    else if(letra1->letra < letra2->letra)
    {
        ret = -1;
    }
    else
    {
        ret = 0;
    }

    return ret;
}

void listar(ArrayList* lista)
{
    int opcion, i, j, rep=0;
    ArrayList* nuevaLista;
    eLetra* auxLetra;
    char letra;

    printf("1. Letras repetidas\n2. Letras sin repetir\n");
    scanf("%d", &opcion);
    switch(opcion)
    {
        case 1:
            nuevaLista = al_newArrayList();
            for(i=0; i< lista->len(lista); i++)
            {
                auxLetra = lista->get(lista, i);
                letra = auxLetra->letra;
                for(j=0; j< lista->len(lista); j++)
                {
                    auxLetra = lista->get(lista, j);
                    if(letra == auxLetra->letra)
                    {
                        rep++;
                    }
                }
                if(rep>1)
                {
                    nuevaLista->add(nuevaLista, lista->get(lista, i));
                }
                rep = 0;
            }
            nuevaLista->sort(nuevaLista, ordenarPorLetra, 1);
            printf("LETRA - NOMBRE - VOCAL - CONS\n");
            for(i=0; i< nuevaLista->len(nuevaLista); i++)
            {
                auxLetra = nuevaLista->get(nuevaLista, i);
                printLetra(auxLetra);
            }
            break;
        case 2:
            nuevaLista = al_newArrayList();
            for(i=0; i< lista->len(lista); i++)
            {
                auxLetra = lista->get(lista, i);
                letra = auxLetra->letra;
                for(j=0; j< nuevaLista->len(nuevaLista); j++)
                {
                    auxLetra = nuevaLista->get(nuevaLista, j);
                    if(letra == auxLetra->letra)
                    {
                       rep++;
                    }
                }
                if(rep==0)
                {
                    nuevaLista->add(nuevaLista, lista->get(lista, i));
                }
                rep = 0;

            }
            nuevaLista->sort(nuevaLista, ordenarPorLetra, 0);
            printf("LETRA - NOMBRE - VOCAL - CONS\n");
            for(i=0; i< nuevaLista->len(nuevaLista); i++)
            {
                auxLetra = nuevaLista->get(nuevaLista, i);
                printLetra(auxLetra);
            }
            break;
        default:
            printf("Opcion invalida, cancelado!\n");
            break;
    }

}

void comprobar(ArrayList* lista)
{
    char palabra[50];
    eLetra* auxLetra;
//    char letra;
    int i, j;
    int hayLetra[50] = {0};

    printf("Ingrese una palabra: ");
    fflush(stdin);
    gets(palabra);

    for(i=0; i< lista->len(lista); i++)
    {
        auxLetra = lista->get(lista, i);
        for(j=0; j< strlen(palabra); j++)
        {
            if(auxLetra->letra == palabra[j])
            {
                hayLetra[j] = 1;
            }
        }
    }

    for(j=0; j< strlen(palabra); j++)
    {
        i = 0;
        if(hayLetra[j] == 0)
        {
            printf("No se puede escribir la palabra, falta la letra %c\n", palabra[j]);
            i = -1;
            break;
        }
    }
    if(i == 0)
    {
        printf("Si se puede escribir la palabra con las letras de la lista.\n");
    }
}
