#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "funciones.h"
#include "arraylist.h"

int main()
{
    int opcion, flag=0;
    char seguir = 's';

    ArrayList* lista = al_newArrayList();

//    int i;
//    eLetra* letra;

    while(seguir == 's')
    {
        opcion = menu();
        switch(opcion)
        {
            case 1:
                if(flag == 0)
                {
                    leerArchivo(lista);
                    flag = 1;
                }

                agregarLetra(lista);
                break;

            case 2:
                if(lista->isEmpty(lista))
                {
                    printf("No hay letras para modificar!\n");
                }
                else
                {
                    modificarLetra(lista);
                }
                break;

            case 3:
                if(lista->isEmpty(lista))
                {
                    printf("No hay letras para borrar!\n");
                }
                else
                {
                    borrarLetra(lista);
                }

                break;
            case 4:
                if(lista->isEmpty(lista))
                {
                    printf("No hay letras para completar!\n");
                }
                else
                {
                   completar(lista);
                }
                break;
            case 5:
                if(lista->isEmpty(lista))
                {
                    printf("No hay letras en la lista!\n");
                }
                else
                {
                    comprobar(lista);
                }
                break;
            case 6:
//                printf("LETRA - NOMBRE - VOCAL - CONS\n");
//                for(i=0; i<lista->len(lista); i++)
//                {
//                    letra = lista->get(lista, i);
//                    printLetra(letra);
//                }
                if(lista->isEmpty(lista))
                {
                    printf("No hay letras para listar!\n");
                }
                else
                {
                    listar(lista);
                }
                break;

            case 7:
                cargarArchivo(lista);
                seguir = 'n';
                break;

            default:
                printf("Error reingrese opcion!\n");
                break;
        }
        system("pause");
        system("cls");
    }
    return 0;
}
